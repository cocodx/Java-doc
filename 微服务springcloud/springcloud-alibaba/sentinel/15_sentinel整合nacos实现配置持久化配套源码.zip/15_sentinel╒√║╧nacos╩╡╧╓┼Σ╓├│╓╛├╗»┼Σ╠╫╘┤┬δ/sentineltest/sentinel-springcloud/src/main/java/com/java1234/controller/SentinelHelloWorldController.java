package com.java1234.controller;


import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2021-05-04 14:35
 */
@RestController
public class SentinelHelloWorldController {


    /**
     * 注解方式定义资源
     * @SentinelResource  value 资源名称
     * @SentinelResource blockHandler 调用被限流/降级/系统保护的时候调用的方法
     * @return
     */
    @SentinelResource(value = "helloWorld_springcloud",blockHandler = "blockHandlerForHelloWorld3")
    @RequestMapping("helloWorld3")
    public String helloWorld3(){
        return "Sentinel 大爷你好！by 注解方式@SentinelResource"+System.currentTimeMillis();
    }

    /**
     * 原方法调用被限流/降级/系统保护的时候调用
     * @param ex
     * @return
     */
    public String blockHandlerForHelloWorld3(BlockException ex) {
        ex.printStackTrace();
        return "系统繁忙，请稍后！";
    }


}