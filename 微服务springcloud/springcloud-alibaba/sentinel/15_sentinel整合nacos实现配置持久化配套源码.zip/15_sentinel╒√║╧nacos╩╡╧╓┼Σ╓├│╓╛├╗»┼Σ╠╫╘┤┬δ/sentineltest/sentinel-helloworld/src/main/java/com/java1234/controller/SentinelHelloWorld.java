package com.java1234.controller;

import com.alibaba.csp.sentinel.AsyncEntry;
import com.alibaba.csp.sentinel.Entry;
import com.alibaba.csp.sentinel.SphO;
import com.alibaba.csp.sentinel.SphU;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.alibaba.csp.sentinel.slots.block.RuleConstant;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import com.java1234.service.AsyncService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2021-05-04 14:35
 */
@RestController
public class SentinelHelloWorld {


    @Autowired
    private AsyncService asyncService;

    @RequestMapping("helloWorld")
    public String helloWorld(){
        try(Entry entry=SphU.entry("HelloWorld")){ // 使用限流规则 HelloWorld
            return "Sentinel 大爷你好！"+System.currentTimeMillis();
        }catch (Exception e){
            e.printStackTrace();
            return "系统繁忙，请稍后！";  // 降级处理
        }
    }

    /**
     * 返回布尔值方式定义资源
     * @return
     */
    @RequestMapping("helloWorld2")
    public String helloWorld2(){
        // 资源名可使用任意有业务语义的字符串
        if (SphO.entry("HelloWorld2")) {
            // 务必保证finally会被执行
            try {
                /**
                 * 被保护的业务逻辑
                 */
                return "Sentinel 大爷你好！boolean"+System.currentTimeMillis();
            } finally {
                SphO.exit();
            }
        } else {
            // 资源访问阻止，被限流或被降级
            // 进行相应的处理操作
            return "系统繁忙，请稍后！";  // 降级处理
        }
    }

    /**
     * 注解方式定义资源
     * @SentinelResource  value 资源名称
     * @SentinelResource blockHandler 调用被限流/降级/系统保护的时候调用的方法
     * @return
     */
    @SentinelResource(value = "helloWorld3",blockHandler = "blockHandlerForHelloWorld3")
    @RequestMapping("helloWorld3")
    public String helloWorld3(){
        return "Sentinel 大爷你好！by 注解方式@SentinelResource"+System.currentTimeMillis();
    }

    /**
     * 原方法调用被限流/降级/系统保护的时候调用
     * @param ex
     * @return
     */
    public String blockHandlerForHelloWorld3(BlockException ex) {
        ex.printStackTrace();
        return "系统繁忙，请稍后！";
    }

    @RequestMapping("helloWorld4")
    public void helloWorld4(){
        AsyncEntry asyncEntry =null;
        try {
            asyncEntry = SphU.asyncEntry("helloWorld4");
            asyncService.doSomethingAsync();
        } catch (BlockException e) {
            System.out.println("系统繁忙，请稍后！");
        }finally {
            if(asyncEntry!=null){
                asyncEntry.exit();
            }
        }
    }



    /*
     * 定义限流规则
     * PostConstruct 构造方法执行完后执行方法 定义和加载限流规则
    */
    /*@PostConstruct
    public void initFlowRules(){
        List<FlowRule> rules=new ArrayList<>(); // 定义限流规则集合
        FlowRule rule=new FlowRule();  // 定义限流规则
        rule.setResource("HelloWorld");  // 定义限流资源
        rule.setGrade(RuleConstant.FLOW_GRADE_QPS); // 定义限流规则类型
        rule.setCount(2); // 定义QPS阈值 每秒最多通过的请求个数
        rules.add(rule);  // 添加规则到集合
        FlowRuleManager.loadRules(rules); // 加载规则集合
    }*/
}