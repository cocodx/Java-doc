package com.java1234.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2021-05-27 13:18
 */
@Service
public class AsyncService {

    @Async
    public void doSomethingAsync(){
        System.out.println("async start...");
        try {
        Thread.sleep(4000);
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
        System.out.println("async end...");
}
}
