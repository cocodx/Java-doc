package com.java1234;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2021-05-04 15:18
 */
@SpringBootApplication
@EnableAsync
public class SentinelHelloWorldApplication {

    public static void main(String[] args) {
        SpringApplication.run(SentinelHelloWorldApplication.class,args);
    }
}