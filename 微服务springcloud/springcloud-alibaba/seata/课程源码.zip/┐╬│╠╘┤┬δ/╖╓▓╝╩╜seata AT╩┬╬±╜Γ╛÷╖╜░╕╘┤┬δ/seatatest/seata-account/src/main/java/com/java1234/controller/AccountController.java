package com.java1234.controller;

import com.java1234.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 账户Controller
 * @author java1234_小锋
 * @site www.java1234.com
 * @company 南通小锋网络科技有限公司
 * @create 2021-07-15 13:06
 */
@RestController
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private AccountService accountService;

    /**
     * 给指定用户账户扣钱
     * @param amount
     * @param userId
     * @return
     */
    @PostMapping("/decrease")
    public boolean decrease(@RequestParam("amount")Integer amount, @RequestParam("userId")Integer userId)throws Exception{
        System.out.println("amount:"+amount+",userId:"+userId);

        if(userId==null || userId==1){
            throw new Exception("模拟异常");
        }

        Map<String,Object> map=new HashMap<>();
        map.put("amount",amount);
        map.put("userId",userId);

        accountService.decrease(map);
        return true;

    }

}
