package com.java1234.controller;

import com.java1234.entity.Order;
import com.java1234.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * @author java1234_小锋
 * @site www.java1234.com
 * @company 南通小锋网络科技有限公司
 * @create 2021-07-14 11:13
 */
@RestController
@RequestMapping("/seata")
public class OrderController {

    @Autowired
    private OrderService orderService;

    /**
     * 创建订单
     * @param order
     * @return
     */
    @PostMapping("/createOrder")
    public boolean createOrder(@RequestBody Order order){
        System.out.println("order:"+order);

        order.setOrderNo(UUID.randomUUID().toString());  // 生成订单ID
        orderService.createOrder(order);
        return true;

    }
}
