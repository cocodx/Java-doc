package com.java1234.controller;

import com.java1234.entity.Order;
import com.java1234.feign.AccountFeignService;
import com.java1234.feign.OrderFeignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * web-rest接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company 南通小锋网络科技有限公司
 * @create 2021-07-15 16:32
 */
@RestController
public class WebController {

    @Autowired
    private OrderFeignService orderFeignService;

    @Autowired
    private AccountFeignService  accountFeignService;

    /**
     * 下单 1，创建订单 2，账户扣钱
     * @param order
     * @return
     */
    @PostMapping("/shopping")
    public boolean shopping(Order order){
        orderFeignService.createOrder(order); // 创建订单
        accountFeignService.decrease(order.getAmount(),order.getUserId()); // 账户扣钱
        return true;
    }


}
